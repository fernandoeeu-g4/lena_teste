const fs = require('fs')
const gerador = require('./insere_ing')
let data = []
let id = 1
for (let i = 0; i < 10000; i++) {
  items = gerador(5)
  let new_item = {
    id: id,
    nome: `receita ${id}`,
    ing: items
  }
  data.push(new_item)
  id++
}


data = JSON.stringify(data)

// console.log(data)
fs.appendFile('./receitas.js', data, 'utf-8',
  function (err) {
    if (err) {
      return console.log(err)
    }
    id++
    console.log("appended")
  })